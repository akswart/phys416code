# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 14:05:50 2020

@author: aks13
"""

h = np.linspace(1,num=10,retstep=10**-.5)
logspace????